  Griggorii@gmail.com my edit pythone file delete string green-recorder adaptation ubuntu 20.04 not check run 18.04 , 18.10 , 19.04 , 19.10 , 20.10


 sudo pip install pydbus
    
The source code is available to download via: [https://github.com/green-project/green-recorder/archive/master.zip](https://github.com/green-project/green-recorder/archive/master.zip). You can simply download it and install the dependencies on your distribution (gir1.2-appindicator3, gawk, python-gobject, python-urllib3, x11-utils, ffmpeg, pydbus, pulseaudio, xdg-open (or xdg-utils), python-configparser, imagemagick). And then run: 

green-recorder/bin run

./green-recorder

install example ubuntu X64 command in run terminal folder green-recorder:

sudo cp -r ./bin ./share /usr

____________________________________________________________________________________

Not dstr ubuntu locale gento ? Test install

sudo cp -r ./bin ./lib ./share /usr/local

____________________________________________________________________________________

My OS job https://github.com/Griggorii/Linux_OS20.04_V2_X64_By_Griggorii.iso_ubuntu_focal_fossa-linux-image-5.4.0-29





